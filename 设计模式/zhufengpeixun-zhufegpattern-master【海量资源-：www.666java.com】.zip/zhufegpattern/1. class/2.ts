let obj6;
obj6 = 1;